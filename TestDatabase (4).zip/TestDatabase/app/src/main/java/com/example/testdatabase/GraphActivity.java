package com.example.testdatabase;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class GraphActivity extends AppCompatActivity {

    private int temp = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);
        GraphView graph = (GraphView) findViewById(R.id.graph);

        Intent intent = getIntent();
        temp = intent.getIntExtra("Temp",0);
        Log.e(GraphActivity.class.getSimpleName(),"TEMP: " + temp);

        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(new DataPoint[] {
                new DataPoint(0, temp),
                new DataPoint(1, temp+1),
                new DataPoint(2, temp+2),
        });
        graph.addSeries(series);
    }
}
