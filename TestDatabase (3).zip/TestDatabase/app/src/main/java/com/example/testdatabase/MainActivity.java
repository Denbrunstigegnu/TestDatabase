package com.example.testdatabase;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private FirebaseDatabase database;
    private DatabaseReference myRef;
    private Button DatabaseButton;
    private TextView ButtonView;
    private TextView TempView;
    private DatabaseReference myRef2;
    private TextView KvalliView;
    private TextView StøjView;
    private TextView FugtighedView;
    private DatabaseReference KvalliRef;
    private DatabaseReference StøjRef;
    private DatabaseReference FugtighedRef;

    int count = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Write a message to the database
        database = FirebaseDatabase.getInstance();
        //myRef = database.getReference("message");

        //myRef.setValue("Hello, World!");

        DatabaseButton = findViewById(R.id.button);
        ButtonView = findViewById(R.id.textView2);
        TempView = findViewById(R.id.tempView);
        KvalliView = findViewById(R.id.kvallitetView);
        StøjView = findViewById(R.id.støjView);
        FugtighedView = findViewById(R.id.fugtighedView);
        myRef = database.getReference().child("Button");
        myRef2 = database.getReference().child("Temperatur");
        KvalliRef = database.getReference().child("Kvallitet");
        StøjRef = database.getReference().child("Støj");
        FugtighedRef = database.getReference().child("Fugtighed");

        FugtighedRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String Fugtighed = dataSnapshot.getValue().toString();
                FugtighedView.setText("Fugtighed "+ Fugtighed);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        StøjRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String Støj = dataSnapshot.getValue().toString();
                StøjView.setText("Støj "+ Støj);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        KvalliRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String Kvalli = dataSnapshot.getValue().toString();
                KvalliView.setText("Kvallitet "+ Kvalli);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                String Button = dataSnapshot.getValue().toString();

                ButtonView.setText("Button: "+ Button );
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        myRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String Temp = dataSnapshot.getValue().toString();

                TempView.setText("Temp "+ Temp);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        DatabaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                myRef = database.getReference("Button " + count);


                String uniqueID = UUID.randomUUID().toString();
                myRef.setValue(uniqueID);

                count++;

            }
        });
    }
}
